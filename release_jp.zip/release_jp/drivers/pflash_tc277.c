/*
 * TC277 PFLASH レジスタレベルドライバ（骨格実装）
 * 注意: 以下のレジスタアドレス／ビット定義はプレースホルダです。
 *       プロジェクトの TC277 ヘッダの実定義に置き換えてください。
 */

#include "pflash_tc277.h"
#include "ifx_tc27x_flash_regs.h"
#include <string.h>

/* ===================== レジスタマッピングの出所 ===================== */
/* 本ファイルは drivers/ifx_tc27x_flash_regs.h のレジスタ／ビットマクロを使用します。
 * 同ヘッダに iLLD 由来の正確なアドレス、オフセット、ビット定義、コマンド列を記入してください。 */

/* ===================== ドライバ内部状態 ===================== */

static pflash_cfg_t g_cfg;
static pflash_endinit_ops_t g_endinit = { 0 };

void pflash_set_endinit_ops(const pflash_endinit_ops_t *ops)
{
	if (ops)
	{
		g_endinit = *ops;
	}
}

void pflash_init(const pflash_cfg_t *cfg)
{
	if (cfg)
	{
		g_cfg = *cfg;
	}
}

bool pflash_is_busy(void)
{
	return (FLASH_FSR & FSR_BUSY_MASK) != 0u;
}

pflash_status_t pflash_wait_ready(uint32_t timeoutCycles)
{
	while (pflash_is_busy())
	{
		if (timeoutCycles == 0u)
		{
			return PFLASH_ERR_TIMEOUT;
		}
		--timeoutCycles;
	}
	return PFLASH_OK;
}

void pflash_clear_status(void)
{
	/* IfxFlash_clearStatus に相当するコマンドポート列（IfxFlash.h line 501-509） */
	volatile uint32_t *cmd = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | 0x5554u);
	*cmd = FLASH_CLEAR_STATUS_CMD;
	__asm__ volatile ("dsync" ::: "memory");
}

static inline bool is_aligned(uint32_t addr, uint32_t align)
{
	return (addr % align) == 0u;
}

static inline void endinit_clear(void)
{
	if (g_endinit.clearEndinit) { g_endinit.clearEndinit(); }
}

static inline void endinit_set(void)
{
	if (g_endinit.setEndinit) { g_endinit.setEndinit(); }
}

/* ダミーデータバッファレジスタへのコピー（プレースホルダ）；
 * 実際の TC277 では固定ページサイズおよび複数データレジスタ／バッファ書込シーケンスを
 * 対応するレジスタ書込に置き換えてください。 */
static void load_program_buffer(const uint8_t *src, uint32_t len)
{
	/* コマンドポートでページバッファをロード（IfxFlash_loadPage2X32 相当）:
	 * IFXFLASH_CMD_BASE_ADDRESS|0x55F0 に 32bit 単位で書き込みキャッシュを埋める。
	 */
	volatile uint32_t *cmdBuf = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_LOADBUF);
	uint32_t words = len / 4u;
	for (uint32_t i = 0; i < words; ++i)
	{
		uint32_t w;
		memcpy(&w, src + i * 4u, 4u);
		cmdBuf[0] = w;
	}
}

/* addr: 絶対アドレス */
pflash_status_t RAMFUNC pflash_erase_sector(uint32_t addr)
{
	if (!is_aligned(addr, g_cfg.sectorSizeBytes))
	{
		return PFLASH_ERR_ALIGN;
	}

	/* アイドル待ちとステータスクリア */
	if (pflash_wait_ready(0x3FFFFFFFu) != PFLASH_OK)
	{
		return PFLASH_ERR_BUSY;
	}
	pflash_clear_status();

	/* ENDINIT 保護: 一部レジスタ書込には ENDINIT 解除が必要 */
	endinit_clear();

	/* IfxFlash_eraseSector と同一シーケンス（IfxFlash.h line 580-593） */
	volatile uint32_t *addr_port = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_ERASE_ADDR);
	volatile uint32_t *num_port  = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_ERASE_NUM);
	volatile uint32_t *exec_port = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_EXECUTE);

	*addr_port = addr;
	*num_port  = 1u;
	*exec_port = FLASH_ERASE_CMD1; /* 0x80 */
	*exec_port = FLASH_ERASE_CMD2; /* 0x50 */
	__asm__ volatile ("dsync" ::: "memory");

	endinit_set();

	/* 完了待ち */
	pflash_status_t st = pflash_wait_ready(0x7FFFFFFFu);
	if (st != PFLASH_OK) { return st; }

	/* エラーチェック */
	uint32_t fsr = FLASH_FSR;
	if (fsr & FSR_ERASEERR_MASK) { return PFLASH_ERR_ERASE; }
	return PFLASH_OK;
}

/* addr: 絶対アドレス；len は pageSize と等しいこと */
pflash_status_t RAMFUNC pflash_program_page(uint32_t addr, const void *src, uint32_t len)
{
	if ((src == NULL) || (len != g_cfg.pageSizeBytes))
	{
		return PFLASH_ERR_PARAM;
	}
	if (!is_aligned(addr, g_cfg.pageSizeBytes))
	{
		return PFLASH_ERR_ALIGN;
	}

	if (pflash_wait_ready(0x3FFFFFFFu) != PFLASH_OK)
	{
		return PFLASH_ERR_BUSY;
	}
	pflash_clear_status();

	/* 1. PageMode へ遷移（IfxFlash_enterPageMode line 512-529） */
	volatile uint32_t *enter_page = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_ENTER_PAGEMODE);
	if ((addr & 0xFF000000u) == IFXFLASH_PFLASH_START)
	{
		*enter_page = FLASH_ENTER_PAGE_PFLASH; /* 0x50 */
	}
	else if ((addr & 0xFF000000u) == IFXFLASH_DFLASH_START)
	{
		*enter_page = FLASH_ENTER_PAGE_DFLASH; /* 0x5D */
	}
	__asm__ volatile ("dsync" ::: "memory");

	/* 2. ページバッファのロード */
	load_program_buffer((const uint8_t *)src, len);

	/* 3. ページ書込トリガ（IfxFlash_writePage line 747-760） */
	volatile uint32_t *wr_addr = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_ERASE_ADDR);
	volatile uint32_t *wr_num  = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_ERASE_NUM);
	volatile uint32_t *exec    = (volatile uint32_t *)(uintptr_t)(IFXFLASH_CMD_BASE_ADDRESS | CMD_OFF_EXECUTE);
	*wr_addr = addr;
	*wr_num  = 0x00u;
	*exec    = FLASH_WRITE_PAGE_CMD1; /* 0xA0 */
	*exec    = FLASH_WRITE_PAGE_CMD2; /* 0xAA */
	__asm__ volatile ("dsync" ::: "memory");

	pflash_status_t st = pflash_wait_ready(0x7FFFFFFFu);
	if (st != PFLASH_OK) { return st; }

	uint32_t fsr = FLASH_FSR;
	if (fsr & FSR_PROGERR_MASK) { return PFLASH_ERR_PROG; }
	return PFLASH_OK;
}

void pflash_read(uint32_t addr, void *dst, uint32_t len)
{
	memcpy(dst, (const void *)(uintptr_t)addr, len);
}


