/*
 * TC277 FLASH セクタテーブル（iLLD v1.20.0 から抽出）
 * セクタアドレス照会用ヘルパ関数と定数を提供します。
 * 出所: D:\Infineon\iLLD\TC2x\v1.20.0\TC27D-v1.20.0\Src\BaseSw\iLLD\TC27D\Tricore\_Impl\IfxFlash_cfg.c
 */

#ifndef DRIVERS_TC277_SECTOR_TABLE_H
#define DRIVERS_TC277_SECTOR_TABLE_H

#include <stdint.h>
#include <stdbool.h>

/* ================= セクタ数定数 ================= */
#define TC277_PFLASH_LOG_SECTORS       (54u)  /* PFLASH 論理セクタ総数（2 banks × 27） */
#define TC277_PFLASH_PHYS_SECTORS      (8u)   /* PFLASH 物理セクタ総数（2 banks × 4） */
#define TC277_DFLASH_EEP_LOG_SECTORS   (48u)  /* DFLASH EEP 論理セクタ数 */
#define TC277_DFLASH_HSM_LOG_SECTORS   (8u)   /* DFLASH HSM 論理セクタ数 */
#define TC277_DFLASH_UCB_LOG_SECTORS   (16u)  /* DFLASH UCB 論理セクタ数 */

/* ================= セクタ構造体 ================= */
typedef struct
{
	uint32_t start;  /* セクタ先頭アドレス */
	uint32_t end;    /* セクタ終端アドレス（含む） */
} tc277_sector_t;

/* ================= PFLASH 論理セクタテーブル（読取専用） ================= */
extern const tc277_sector_t tc277_pflash_log_sectors[TC277_PFLASH_LOG_SECTORS];

/* ================= PFLASH 物理セクタテーブル（読取専用） ================= */
extern const tc277_sector_t tc277_pflash_phys_sectors[TC277_PFLASH_PHYS_SECTORS];

/* ================= DFLASH EEP 論理セクタテーブル（読取専用） ================= */
extern const tc277_sector_t tc277_dflash_eep_log_sectors[TC277_DFLASH_EEP_LOG_SECTORS];

/* ================= DFLASH HSM 論理セクタテーブル（読取専用） ================= */
extern const tc277_sector_t tc277_dflash_hsm_log_sectors[TC277_DFLASH_HSM_LOG_SECTORS];

/* ================= DFLASH UCB 論理セクタテーブル（読取専用） ================= */
extern const tc277_sector_t tc277_dflash_ucb_log_sectors[TC277_DFLASH_UCB_LOG_SECTORS];

/* ================= ヘルパ関数 ================= */

/**
 * @brief アドレスが属する PFLASH 論理セクタのインデックスを取得
 * @param addr 対象アドレス
 * @param[out] sector_idx セクタインデックス（0-53）を返す
 * @return true 見つかった、false は PFLASH 範囲外
 */
bool tc277_get_pflash_sector_idx(uint32_t addr, uint32_t *sector_idx);

/**
 * @brief アドレスが属する DFLASH EEP 論理セクタのインデックスを取得
 * @param addr 対象アドレス
 * @param[out] sector_idx セクタインデックス（0-47）を返す
 * @return true 見つかった、false は DFLASH EEP 範囲外
 */
bool tc277_get_dflash_eep_sector_idx(uint32_t addr, uint32_t *sector_idx);

/**
 * @brief PFLASH 論理セクタのサイズ（バイト）を取得
 * @param sector_idx セクタインデックス（0-53）
 * @return セクタサイズ。インデックス無効時は 0
 */
uint32_t tc277_get_pflash_sector_size(uint32_t sector_idx);

/**
 * @brief DFLASH EEP 論理セクタのサイズ（バイト）を取得
 * @param sector_idx セクタインデックス（0-47）
 * @return セクタサイズ（固定 8192）。インデックス無効時は 0
 */
uint32_t tc277_get_dflash_eep_sector_size(uint32_t sector_idx);

#endif /* DRIVERS_TC277_SECTOR_TABLE_H */



