/*
 * TC277 FLASH セクタテーブル実装（iLLD v1.20.0 IfxFlash_cfg.c から抽出）
 */

#include "tc277_sector_table.h"

/* ================= PFLASH 論理セクタテーブル（54 個） ================= */
const tc277_sector_t tc277_pflash_log_sectors[TC277_PFLASH_LOG_SECTORS] = {
	/* PF0 Bank (0xA0000000 - 0xA01FFFFF) */
	{0xA0000000, 0xA0003FFF},  /*  0: PF0-S0   16KB */
	{0xA0004000, 0xA0007FFF},  /*  1: PF0-S1   16KB */
	{0xA0008000, 0xA000BFFF},  /*  2: PF0-S2   16KB */
	{0xA000C000, 0xA000FFFF},  /*  3: PF0-S3   16KB */
	{0xA0010000, 0xA0013FFF},  /*  4: PF0-S4   16KB */
	{0xA0014000, 0xA0017FFF},  /*  5: PF0-S5   16KB */
	{0xA0018000, 0xA001BFFF},  /*  6: PF0-S6   16KB */
	{0xA001C000, 0xA001FFFF},  /*  7: PF0-S7   16KB */
	{0xA0020000, 0xA0027FFF},  /*  8: PF0-S8   32KB */
	{0xA0028000, 0xA002FFFF},  /*  9: PF0-S9   32KB */
	{0xA0030000, 0xA0037FFF},  /* 10: PF0-S10  32KB */
	{0xA0038000, 0xA003FFFF},  /* 11: PF0-S11  32KB */
	{0xA0040000, 0xA0047FFF},  /* 12: PF0-S12  32KB */
	{0xA0048000, 0xA004FFFF},  /* 13: PF0-S13  32KB */
	{0xA0050000, 0xA0057FFF},  /* 14: PF0-S14  32KB */
	{0xA0058000, 0xA005FFFF},  /* 15: PF0-S15  32KB */
	{0xA0060000, 0xA006FFFF},  /* 16: PF0-S16  64KB */
	{0xA0070000, 0xA007FFFF},  /* 17: PF0-S17  64KB */
	{0xA0080000, 0xA008FFFF},  /* 18: PF0-S18  64KB */
	{0xA0090000, 0xA009FFFF},  /* 19: PF0-S19  64KB */
	{0xA00A0000, 0xA00BFFFF},  /* 20: PF0-S20  128KB */
	{0xA00C0000, 0xA00DFFFF},  /* 21: PF0-S21  128KB */
	{0xA00E0000, 0xA00FFFFF},  /* 22: PF0-S22  128KB */
	{0xA0100000, 0xA013FFFF},  /* 23: PF0-S23  256KB */
	{0xA0140000, 0xA017FFFF},  /* 24: PF0-S24  256KB */
	{0xA0180000, 0xA01BFFFF},  /* 25: PF0-S25  256KB */
	{0xA01C0000, 0xA01FFFFF},  /* 26: PF0-S26  256KB */

	/* PF1 Bank (0xA0200000 - 0xA03FFFFF) */
	{0xA0200000, 0xA0203FFF},  /* 27: PF1-S0   16KB */
	{0xA0204000, 0xA0207FFF},  /* 28: PF1-S1   16KB */
	{0xA0208000, 0xA020BFFF},  /* 29: PF1-S2   16KB */
	{0xA020C000, 0xA020FFFF},  /* 30: PF1-S3   16KB */
	{0xA0210000, 0xA0213FFF},  /* 31: PF1-S4   16KB */
	{0xA0214000, 0xA0217FFF},  /* 32: PF1-S5   16KB */
	{0xA0218000, 0xA021BFFF},  /* 33: PF1-S6   16KB */
	{0xA021C000, 0xA021FFFF},  /* 34: PF1-S7   16KB */
	{0xA0220000, 0xA0227FFF},  /* 35: PF1-S8   32KB */
	{0xA0228000, 0xA022FFFF},  /* 36: PF1-S9   32KB */
	{0xA0230000, 0xA0237FFF},  /* 37: PF1-S10  32KB */
	{0xA0238000, 0xA023FFFF},  /* 38: PF1-S11  32KB */
	{0xA0240000, 0xA0247FFF},  /* 39: PF1-S12  32KB */
	{0xA0248000, 0xA024FFFF},  /* 40: PF1-S13  32KB */
	{0xA0250000, 0xA0257FFF},  /* 41: PF1-S14  32KB */
	{0xA0258000, 0xA025FFFF},  /* 42: PF1-S15  32KB */
	{0xA0260000, 0xA026FFFF},  /* 43: PF1-S16  64KB */
	{0xA0270000, 0xA027FFFF},  /* 44: PF1-S17  64KB */
	{0xA0280000, 0xA028FFFF},  /* 45: PF1-S18  64KB */
	{0xA0290000, 0xA029FFFF},  /* 46: PF1-S19  64KB */
	{0xA02A0000, 0xA02BFFFF},  /* 47: PF1-S20  128KB */
	{0xA02C0000, 0xA02DFFFF},  /* 48: PF1-S21  128KB */
	{0xA02E0000, 0xA02FFFFF},  /* 49: PF1-S22  128KB */
	{0xA0300000, 0xA033FFFF},  /* 50: PF1-S23  256KB */
	{0xA0340000, 0xA037FFFF},  /* 51: PF1-S24  256KB */
	{0xA0380000, 0xA03BFFFF},  /* 52: PF1-S25  256KB */
	{0xA03C0000, 0xA03FFFFF},  /* 53: PF1-S26  256KB */
};

/* ================= PFLASH 物理セクタテーブル（8 個、各 512KB） ================= */
const tc277_sector_t tc277_pflash_phys_sectors[TC277_PFLASH_PHYS_SECTORS] = {
	{0xA0000000, 0xA007FFFF},  /* 0: PF0-PS0  512KB */
	{0xA0080000, 0xA00FFFFF},  /* 1: PF0-PS1  512KB */
	{0xA0100000, 0xA017FFFF},  /* 2: PF0-PS2  512KB */
	{0xA0180000, 0xA01FFFFF},  /* 3: PF0-PS3  512KB */
	{0xA0200000, 0xA027FFFF},  /* 4: PF1-PS0  512KB */
	{0xA0280000, 0xA02FFFFF},  /* 5: PF1-PS1  512KB */
	{0xA0300000, 0xA037FFFF},  /* 6: PF1-PS2  512KB */
	{0xA0380000, 0xA03FFFFF},  /* 7: PF1-PS3  512KB */
};

/* ================= DFLASH EEP 論理セクタテーブル（48 個、各 8KB） ================= */
const tc277_sector_t tc277_dflash_eep_log_sectors[TC277_DFLASH_EEP_LOG_SECTORS] = {
	{0xAF000000, 0xAF001FFF},  /*  0 */
	{0xAF002000, 0xAF003FFF},  /*  1 */
	{0xAF004000, 0xAF005FFF},  /*  2 */
	{0xAF006000, 0xAF007FFF},  /*  3 */
	{0xAF008000, 0xAF009FFF},  /*  4 */
	{0xAF00A000, 0xAF00BFFF},  /*  5 */
	{0xAF00C000, 0xAF00DFFF},  /*  6 */
	{0xAF00E000, 0xAF00FFFF},  /*  7 */
	{0xAF010000, 0xAF011FFF},  /*  8 */
	{0xAF012000, 0xAF013FFF},  /*  9 */
	{0xAF014000, 0xAF015FFF},  /* 10 */
	{0xAF016000, 0xAF017FFF},  /* 11 */
	{0xAF018000, 0xAF019FFF},  /* 12 */
	{0xAF01A000, 0xAF01BFFF},  /* 13 */
	{0xAF01C000, 0xAF01DFFF},  /* 14 */
	{0xAF01E000, 0xAF01FFFF},  /* 15 */
	{0xAF020000, 0xAF021FFF},  /* 16 */
	{0xAF022000, 0xAF023FFF},  /* 17 */
	{0xAF024000, 0xAF025FFF},  /* 18 */
	{0xAF026000, 0xAF027FFF},  /* 19 */
	{0xAF028000, 0xAF029FFF},  /* 20 */
	{0xAF02A000, 0xAF02BFFF},  /* 21 */
	{0xAF02C000, 0xAF02DFFF},  /* 22 */
	{0xAF02E000, 0xAF02FFFF},  /* 23 */
	{0xAF030000, 0xAF031FFF},  /* 24 */
	{0xAF032000, 0xAF033FFF},  /* 25 */
	{0xAF034000, 0xAF035FFF},  /* 26 */
	{0xAF036000, 0xAF037FFF},  /* 27 */
	{0xAF038000, 0xAF039FFF},  /* 28 */
	{0xAF03A000, 0xAF03BFFF},  /* 29 */
	{0xAF03C000, 0xAF03DFFF},  /* 30 */
	{0xAF03E000, 0xAF03FFFF},  /* 31 */
	{0xAF040000, 0xAF041FFF},  /* 32 */
	{0xAF042000, 0xAF043FFF},  /* 33 */
	{0xAF044000, 0xAF045FFF},  /* 34 */
	{0xAF046000, 0xAF047FFF},  /* 35 */
	{0xAF048000, 0xAF049FFF},  /* 36 */
	{0xAF04A000, 0xAF04BFFF},  /* 37 */
	{0xAF04C000, 0xAF04DFFF},  /* 38 */
	{0xAF04E000, 0xAF04FFFF},  /* 39 */
	{0xAF050000, 0xAF051FFF},  /* 40 */
	{0xAF052000, 0xAF053FFF},  /* 41 */
	{0xAF054000, 0xAF055FFF},  /* 42 */
	{0xAF056000, 0xAF057FFF},  /* 43 */
	{0xAF058000, 0xAF059FFF},  /* 44 */
	{0xAF05A000, 0xAF05BFFF},  /* 45 */
	{0xAF05C000, 0xAF05DFFF},  /* 46 */
	{0xAF05E000, 0xAF05FFFF},  /* 47 */
};

/* ================= DFLASH HSM 論理セクタテーブル（8 個、各 8KB） ================= */
const tc277_sector_t tc277_dflash_hsm_log_sectors[TC277_DFLASH_HSM_LOG_SECTORS] = {
	{0xAF110000, 0xAF111FFF},  /* HSM0 */
	{0xAF112000, 0xAF113FFF},  /* HSM1 */
	{0xAF114000, 0xAF115FFF},  /* HSM2 */
	{0xAF116000, 0xAF117FFF},  /* HSM3 */
	{0xAF118000, 0xAF119FFF},  /* HSM4 */
	{0xAF11A000, 0xAF11BFFF},  /* HSM5 */
	{0xAF11C000, 0xAF11DFFF},  /* HSM6 */
	{0xAF11E000, 0xAF11FFFF},  /* HSM7 */
};

/* ================= DFLASH UCB 論理セクタテーブル（16 個、各 1KB） ================= */
const tc277_sector_t tc277_dflash_ucb_log_sectors[TC277_DFLASH_UCB_LOG_SECTORS] = {
	{0xAF100000, 0xAF1003FF},  /* UCB0 */
	{0xAF100400, 0xAF1007FF},  /* UCB1 */
	{0xAF100800, 0xAF100BFF},  /* UCB2 */
	{0xAF100C00, 0xAF100FFF},  /* UCB3 */
	{0xAF101000, 0xAF1013FF},  /* UCB4 */
	{0xAF101400, 0xAF1017FF},  /* UCB5 */
	{0xAF101800, 0xAF101BFF},  /* UCB6 */
	{0xAF101C00, 0xAF101FFF},  /* UCB7 */
	{0xAF102000, 0xAF1023FF},  /* UCB8 */
	{0xAF102400, 0xAF1027FF},  /* UCB9 */
	{0xAF102800, 0xAF102BFF},  /* UCB10 */
	{0xAF102C00, 0xAF102FFF},  /* UCB11 */
	{0xAF103000, 0xAF1033FF},  /* UCB12 */
	{0xAF103400, 0xAF1037FF},  /* UCB13 */
	{0xAF103800, 0xAF103BFF},  /* UCB14 */
	{0xAF103C00, 0xAF103FFF},  /* UCB15 */
};

/* ================= ヘルパ関数実装 ================= */

bool tc277_get_pflash_sector_idx(uint32_t addr, uint32_t *sector_idx)
{
	if (sector_idx == NULL) { return false; }

	for (uint32_t i = 0; i < TC277_PFLASH_LOG_SECTORS; ++i)
	{
		if (addr >= tc277_pflash_log_sectors[i].start && addr <= tc277_pflash_log_sectors[i].end)
		{
			*sector_idx = i;
			return true;
		}
	}
	return false;
}

bool tc277_get_dflash_eep_sector_idx(uint32_t addr, uint32_t *sector_idx)
{
	if (sector_idx == NULL) { return false; }

	for (uint32_t i = 0; i < TC277_DFLASH_EEP_LOG_SECTORS; ++i)
	{
		if (addr >= tc277_dflash_eep_log_sectors[i].start && addr <= tc277_dflash_eep_log_sectors[i].end)
		{
			*sector_idx = i;
			return true;
		}
	}
	return false;
}

uint32_t tc277_get_pflash_sector_size(uint32_t sector_idx)
{
	if (sector_idx >= TC277_PFLASH_LOG_SECTORS) { return 0; }
	return (tc277_pflash_log_sectors[sector_idx].end - tc277_pflash_log_sectors[sector_idx].start + 1u);
}

uint32_t tc277_get_dflash_eep_sector_size(uint32_t sector_idx)
{
	if (sector_idx >= TC277_DFLASH_EEP_LOG_SECTORS) { return 0; }
	return 0x2000u; /* DFLASH EEP は固定 8KB */
}


