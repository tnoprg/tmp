/*
 * TC277 PFLASH レジスタレベルドライバ（骨格）
 * 説明:
 * - 本ファイルおよび pflash_tc277.c 内のレジスタアドレス／ビット定義マクロを、
 *   プロジェクトのチップヘッダの実定義に置き換えてください。
 * - 消去／プログラムコードは RAM 上で実行することを推奨（RAMFUNC マクロフックあり）
 */

#ifndef DRIVERS_PFLASH_TC277_H
#define DRIVERS_PFLASH_TC277_H

#include <stdint.h>
#include <stdbool.h>

/* 消去／プログラム関数を RAM で実行する属性（使用するコンパイラ／リンカスクリプトに合わせて調整） */
#ifndef RAMFUNC
#define RAMFUNC __attribute__((section(".ramcode")))
#endif

/* 戻り値定義 */
typedef enum
{
	PFLASH_OK = 0,
	PFLASH_ERR_BUSY,
	PFLASH_ERR_TIMEOUT,
	PFLASH_ERR_PROG,
	PFLASH_ERR_ERASE,
	PFLASH_ERR_ALIGN,
	PFLASH_ERR_PARAM
} pflash_status_t;

/* PFLASH パラメータ（チップ構成に応じて変更） */
typedef struct
{
	uint32_t pageSizeBytes;     /* プログラム最小単位（ページ）サイズ */
	uint32_t sectorSizeBytes;   /* 消去最小単位（セクタ）サイズ */
	uint32_t pflashBase;        /* PFLASH ベースアドレス */
} pflash_cfg_t;

/* 初期化（設定の保存のみ） */
void pflash_init(const pflash_cfg_t *cfg);

/* ビジー状態の問い合わせ（FSR 等を読む） */
bool pflash_is_busy(void);

/* アイドル待ち、タイムアウト付き（μs またはループ回数は実装依存） */
pflash_status_t pflash_wait_ready(uint32_t timeoutCycles);

/* ステータスビットのクリア（消去／プログラムエラー等） */
void pflash_clear_status(void);

/* セクタ消去（addr はセクタ境界にアラインすること） */
RAMFUNC pflash_status_t pflash_erase_sector(uint32_t addr);

/* ページプログラム（addr はページ境界、len==pageSizeBytes） */
RAMFUNC pflash_status_t pflash_program_page(uint32_t addr, const void *src, uint32_t len);

/* 単純読み出し（メモリマップ直接アクセス） */
void pflash_read(uint32_t addr, void *dst, uint32_t len);

/* ENDINIT 処理フック：プロジェクトの WDT／ENDINIT 方式に合わせて実装 */
typedef struct
{
	void (*clearEndinit)(void);
	void (*setEndinit)(void);
} pflash_endinit_ops_t;

void pflash_set_endinit_ops(const pflash_endinit_ops_t *ops);

#endif /* DRIVERS_PFLASH_TC277_H */



