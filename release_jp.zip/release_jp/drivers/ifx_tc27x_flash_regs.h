/*
 * TC27x FLASH/DMU レジスタ最小セット（プレースホルダ定義）
 * drivers/pflash_tc277.c 用。iLLD ドキュメント／ヘッダに基づき正確なアドレスとビット定義に置き換えてください。
 * 参考ドキュメント:
 * - http://doc.tasking.com/act/illd_1_0_0_11_0/TC27xD/html/dir_b9705beea4b12c84a96f9dd65bfce9b1.html
 */

#ifndef DRIVERS_IFX_TC27X_FLASH_REGS_H
#define DRIVERS_IFX_TC27X_FLASH_REGS_H

#include <stdint.h>

/* ================= ベースアドレスとオフセット（プレースホルダ） ================ */
#ifndef PFLASH_REG_BASE
#define PFLASH_REG_BASE         (0xF8002000u) /* FLASH0 レジスタブロックベース（IfxFlash_reg.h に基づく） */
#endif

/* コマンドインタフェースベース（iLLD IfxFlash_cfg.h line 71 より） */
#ifndef IFXFLASH_CMD_BASE_ADDRESS
#define IFXFLASH_CMD_BASE_ADDRESS (0xAF000000u) /* TC27D 公式定義 */
#endif

/* PFLASH／DFLASH 先頭アドレスとページ長（IfxFlash_cfg.h より） */
#ifndef IFXFLASH_PFLASH_START
#define IFXFLASH_PFLASH_START     (0xA0000000u) /* line 145 */
#endif
#ifndef IFXFLASH_PFLASH_PAGE_LENGTH
#define IFXFLASH_PFLASH_PAGE_LENGTH (32u)       /* line 137: 32 バイト／ページ */
#endif
#ifndef IFXFLASH_DFLASH_START
#define IFXFLASH_DFLASH_START     (0xAF000000u) /* line 103 */
#endif
#ifndef IFXFLASH_DFLASH_PAGE_LENGTH
#define IFXFLASH_DFLASH_PAGE_LENGTH (8u)        /* line 99: 8 バイト／ページ */
#endif

/* IfxFlash_reg.h より:
 * FLASH0_FSR  = 0xF8002010 → オフセット 0x10
 * FLASH0_FCON = 0xF8002014 → オフセット 0x14
 * FLASH0_MARP = 0xF80020A8 → オフセット 0xA8
 * FLASH0_MARD = 0xF80020AC → オフセット 0xAC
 */
#ifndef REG_FCON_OFFSET
#define REG_FCON_OFFSET         (0x0014u)
#endif
#ifndef REG_FSR_OFFSET
#define REG_FSR_OFFSET          (0x0010u)
#endif
#ifndef REG_MARD_OFFSET
#define REG_MARD_OFFSET         (0x00ACu)
#endif
#ifndef REG_MDBC_OFFSET
#define REG_MDBC_OFFSET         (0x0000u)     /* TC27D 未使用、0 を保持 */
#endif
#ifndef REG_MDB0_OFFSET
#define REG_MDB0_OFFSET         (0x0000u)     /* TC27D 未使用、0 を保持 */
#endif

#define FLASH_REG32(off)        (*(volatile uint32_t *)((PFLASH_REG_BASE) + (uint32_t)(off)))

#define FLASH_FCON              FLASH_REG32(REG_FCON_OFFSET)
#define FLASH_FSR               FLASH_REG32(REG_FSR_OFFSET)
#define FLASH_MARD              FLASH_REG32(REG_MARD_OFFSET)
#define FLASH_MDBC              FLASH_REG32(REG_MDBC_OFFSET)
#define FLASH_MDB0              FLASH_REG32(REG_MDB0_OFFSET)

/* コマンドポートオフセット（IfxFlash.h の例に準拠） */
#ifndef CMD_OFF_ENTER_PAGEMODE
#define CMD_OFF_ENTER_PAGEMODE  (0x5554u)
#endif
#ifndef CMD_OFF_ERASE_ADDR
#define CMD_OFF_ERASE_ADDR      (0xAA50u)
#endif
#ifndef CMD_OFF_ERASE_NUM
#define CMD_OFF_ERASE_NUM       (0xAA58u)
#endif
#ifndef CMD_OFF_EXECUTE
#define CMD_OFF_EXECUTE         (0xAAA8u)
#endif
#ifndef CMD_OFF_LOADBUF
#define CMD_OFF_LOADBUF         (0x55F0u)
#endif

/* ================= FSR ビットマスク（プレースホルダ） ================ */
#ifndef FSR_BUSY_MASK
#define FSR_BUSY_MASK           (1u << 0)     /* FABUSY: Ifx_FLASH_FSR_FABUSY_OFF=0 */
#endif
#ifndef FSR_PROGERR_MASK
#define FSR_PROGERR_MASK        (1u << 13)    /* PROER: Ifx_FLASH_FSR_PROER_OFF=13 */
#endif
#ifndef FSR_ERASEERR_MASK
#define FSR_ERASEERR_MASK       (1u << 26)    /* EVER: Ifx_FLASH_FSR_EVER_OFF=26 */
#endif

/* ================= コマンドコード（IfxFlash.h より） ==================== */
/* 論理セクタ消去シーケンス（IfxFlash_eraseSector，line 580-593） */
#ifndef FLASH_ERASE_CMD1
#define FLASH_ERASE_CMD1        (0x80u)
#endif
#ifndef FLASH_ERASE_CMD2
#define FLASH_ERASE_CMD2        (0x50u)
#endif

/* PageMode 遷移コマンド（IfxFlash_enterPageMode，line 512-529） */
#ifndef FLASH_ENTER_PAGE_PFLASH
#define FLASH_ENTER_PAGE_PFLASH (0x50u)
#endif
#ifndef FLASH_ENTER_PAGE_DFLASH
#define FLASH_ENTER_PAGE_DFLASH (0x5Du)
#endif

/* ページ書込コマンド（IfxFlash_writePage，line 747-760） */
#ifndef FLASH_WRITE_PAGE_CMD1
#define FLASH_WRITE_PAGE_CMD1   (0xA0u)
#endif
#ifndef FLASH_WRITE_PAGE_CMD2
#define FLASH_WRITE_PAGE_CMD2   (0xAAu)
#endif

/* ステータスクリアコマンド（IfxFlash_clearStatus，line 501-509） */
#ifndef FLASH_CLEAR_STATUS_CMD
#define FLASH_CLEAR_STATUS_CMD  (0xFAu)
#endif

#endif /* DRIVERS_IFX_TC27X_FLASH_REGS_H */



