/*
 * TC277 PFLASH レジスタレベルドライバ使用例
 * iLLD から抽出した設定パラメータと ENDINIT 処理の実装例を示します。
 */

#include "pflash_tc277.h"
#include <stdint.h>

/* ==================== ENDINIT 実装（iLLD IfxScuWdt ベース） ==================== */
/* プロジェクトに IfxScuWdt.h がある場合は直接使用。なければ以下の最小実装を参考にしてください。 */

/* 簡易 ENDINIT 操作（参考用。製品では完全な IfxScuWdt API を使用してください） */
#ifndef USE_ILLD_SCU
/* SCU_WDTCPU0 レジスタベース（IfxScu_reg.h 参照） */
#define SCU_WDTCPU0_CON0 (*(volatile uint32_t *)0xF00360F0u)
#define SCU_WDTCPU0_CON1 (*(volatile uint32_t *)0xF00360F4u)

static uint16_t get_wdt_password(void)
{
	/* CON0[15:2] から現在のパスワードを読み取る */
	return (uint16_t)((SCU_WDTCPU0_CON0 >> 2) & 0x3FFFu);
}

static void simple_clear_endinit(void)
{
	uint16_t pw = get_wdt_password();
	/* 1. アンロック（パスワード一致 + LCK=0 + ENDINIT=1） */
	SCU_WDTCPU0_CON0 = ((uint32_t)pw << 2) | (1u << 0) | (0u << 1);
	/* 2. ENDINIT 解除（パスワード一致 + LCK=0 + ENDINIT=0） */
	SCU_WDTCPU0_CON0 = ((uint32_t)pw << 2) | (0u << 0) | (0u << 1);
	/* 3. LCK=1 まで待つ（自動再ロック） */
	while ((SCU_WDTCPU0_CON0 & (1u << 1)) == 0u) {}
}

static void simple_set_endinit(void)
{
	uint16_t pw = get_wdt_password();
	/* 1. アンロック（パスワード一致 + LCK=0 + ENDINIT=0） */
	SCU_WDTCPU0_CON0 = ((uint32_t)pw << 2) | (0u << 0) | (0u << 1);
	/* 2. ENDINIT 設定（パスワード一致 + LCK=0 + ENDINIT=1） */
	SCU_WDTCPU0_CON0 = ((uint32_t)pw << 2) | (1u << 0) | (0u << 1);
	/* 3. LCK=1 まで待つ */
	while ((SCU_WDTCPU0_CON0 & (1u << 1)) == 0u) {}
}
#else
/* iLLD 公式 API を使用 */
#include "IfxScuWdt.h"
static uint16_t g_wdt_password = 0;

static void illd_clear_endinit(void)
{
	g_wdt_password = IfxScuWdt_getCpuWatchdogPassword();
	IfxScuWdt_clearCpuEndinit(g_wdt_password);
}

static void illd_set_endinit(void)
{
	IfxScuWdt_setCpuEndinit(g_wdt_password);
}
#endif

/* ==================== ドライバ初期化と呼び出し例 ==================== */

void example_pflash_usage(void)
{
	/* 1. PFLASH パラメータ設定（iLLD IfxFlash_cfg.h から抽出） */
	pflash_cfg_t cfg = {
		.pageSizeBytes   = 32,           /* IFXFLASH_PFLASH_PAGE_LENGTH = 32 bytes */
		.sectorSizeBytes = 0x4000,       /* 代表的な論理セクタ 16KB（flashSector 表で確認） */
		.pflashBase      = 0xA0000000u   /* IFXFLASH_PFLASH_START */
	};
	pflash_init(&cfg);

	/* 2. ENDINIT 操作フックの登録 */
#ifndef USE_ILLD_SCU
	pflash_endinit_ops_t ops = { simple_clear_endinit, simple_set_endinit };
#else
	pflash_endinit_ops_t ops = { illd_clear_endinit, illd_set_endinit };
#endif
	pflash_set_endinit_ops(&ops);

	/* 3. セクタ消去（セクタ境界にアライン必須。例: 0xA0008000 は第2セクタ先頭） */
	uint32_t sector_addr = 0xA0008000u;
	pflash_status_t st = pflash_erase_sector(sector_addr);
	if (st != PFLASH_OK)
	{
		/* エラー処理 */
		return;
	}

	/* 4. ページプログラム（ページ境界 + 長さは pageSizeBytes と一致）
	 * ページアドレス例: 0xA0008000（セクタ先頭）、0xA0008020（+32 バイト）、0xA0008040… */
	uint8_t page_data[32] = {
		0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
		0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10,
		0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18,
		0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F, 0x20
	};
	uint32_t page_addr = sector_addr; /* セクタ先頭が第1ページ */
	st = pflash_program_page(page_addr, page_data, sizeof(page_data));
	if (st != PFLASH_OK)
	{
		/* エラー処理 */
		return;
	}

	/* 5. 読み戻し検証 */
	uint8_t read_back[32];
	pflash_read(page_addr, read_back, sizeof(read_back));
	/* read_back と page_data を比較 */
}

/* ==================== DFLASH 使用例（任意） ==================== */

void example_dflash_usage(void)
{
	/* DFLASH 設定（IfxFlash_cfg.h ベース） */
	pflash_cfg_t dflash_cfg = {
		.pageSizeBytes   = 8,            /* IFXFLASH_DFLASH_PAGE_LENGTH = 8 bytes */
		.sectorSizeBytes = 0x2000,       /* DFLASH 論理セクタ 8KB（line 101） */
		.pflashBase      = 0xAF000000u   /* IFXFLASH_DFLASH_START */
	};
	pflash_init(&dflash_cfg);

	/* ENDINIT フックは PFLASH と同様 */
#ifndef USE_ILLD_SCU
	pflash_endinit_ops_t ops = { simple_clear_endinit, simple_set_endinit };
#else
	pflash_endinit_ops_t ops = { illd_clear_endinit, illd_set_endinit };
#endif
	pflash_set_endinit_ops(&ops);

	/* 消去／プログラム（アドレスを DFLASH 範囲に変更。それ以外は同様） */
	uint32_t dflash_sector = 0xAF000000u;
	pflash_erase_sector(dflash_sector);

	uint8_t dpage[8] = { 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x11, 0x22 };
	pflash_program_page(dflash_sector, dpage, 8);
}


